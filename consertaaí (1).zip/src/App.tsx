import React, { useState, useEffect, useRef } from 'react';
import { 
  Wrench, Zap, Droplets, Home, AlertTriangle, CheckCircle, Clock, 
  Camera, Upload, Sparkles, PhoneCall, Code, Trash2, ArrowRight, ShieldAlert, 
  Info, Check, RefreshCw, AlertCircle, Share2, ShoppingBag, DollarSign, Mic, MicOff, Square, Award, Crown, Volume2, VolumeX 
} from 'lucide-react';
import { DiagnosisResult, PresetScenario } from './types';

const PRESETS: PresetScenario[] = [
  {
    id: '1',
    title: 'Vazamento embaixo da pia',
    category: 'hidraulica',
    description: 'Água pingando do sifão e poça acumulada no armário da cozinha.'
  },
  {
    id: '2',
    title: 'Disjuntor caindo ao ligar o chuveiro',
    category: 'eletrica',
    description: 'O disjuntor desarma sempre que coloco o chuveiro na posição inverno ou ligo junto com o micro-ondas.'
  },
  {
    id: '3',
    title: 'Infiltração e bolor na parede',
    category: 'infiltracao',
    description: 'Parede descascando na altura do rodapé com cheiro de mofo e manchas escuras.'
  },
  {
    id: '4',
    title: 'Torneira pingando sem parar',
    category: 'hidraulica',
    description: 'Torneira da cozinha gotejando constantemente mesmo fechada com força.'
  },
  {
    id: '5',
    title: 'Tomada faiscando e cheiro de queimado',
    category: 'eletrica',
    description: 'Tomada da geladeira soltou faísca e está com cheiro de plástico queimado.'
  }
];

export default function App() {
  const [description, setDescription] = useState('');
  const [imageFile, setImageFile] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [currentResult, setCurrentResult] = useState<DiagnosisResult | null>(null);
  const [history, setHistory] = useState<DiagnosisResult[]>([]);
  const [activeTab, setActiveTab] = useState<'diagnostico' | 'json' | 'historico' | 'clube'>('diagnostico');
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Audio Recording States (Input)
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // SOS Mão na Massa (Live Voice Mode States)
  const [sosActive, setSosActive] = useState(false);
  const [sosMessages, setSosMessages] = useState<{ sender: 'ai' | 'user'; text: string }[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('conserta_ai_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const saveToHistory = (res: DiagnosisResult) => {
    const newHistory = [res, ...history].slice(0, 15);
    setHistory(newHistory);
    localStorage.setItem('conserta_ai_history', JSON.stringify(newHistory));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageFile(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const startRecording = async () => {
    audioChunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlobObject = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          setAudioBlob(reader.result as string);
        };
        reader.readAsDataURL(audioBlobObject);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setErrorMsg(null);
    } catch (err) {
      console.error(err);
      setErrorMsg('Não foi possível aceder ao microfone. Verifique as permissões.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Text-to-Speech Helper for SOS Mão na Massa
  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'pt-BR';
      utterance.rate = 1.0;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const activateSosMode = () => {
    setSosActive(true);
    const initialGreeting = "Modo SOS Mão na Massa ativado. Respira fundo, estou aqui contigo. Qual é o desespero debaixo da pia ou na parede agora?";
    setSosMessages([{ sender: 'ai', text: initialGreeting }]);
    speakText(initialGreeting);
  };

  const handleSosReply = (userQueryText: string) => {
    if (!userQueryText.trim()) return;
    const newMessages = [...sosMessages, { sender: 'user' as const, text: userQueryText }];
    setSosMessages(newMessages);

    // Simulated contextual AI voice response for hands-free repair
    setTimeout(() => {
      let aiResponse = "Entendido. Foca bem aí: verifica se a rosca está alinhada, segura com firmeza e roda devagar no sentido horário. Me avisa se travou.";
      const lower = userQueryText.toLowerCase();
      if (lower.includes('água') || lower.includes('vazando') || lower.includes('pingando')) {
        aiResponse = "Se a água não pára, vai direto ao registro geral ou fecho o registro angular mais próximo. Conseguiu fechar?";
      } else if (lower.includes('cheiro') || lower.includes('fio') || lower.includes('disjuntor')) {
        aiResponse = "Atenção máxima com eletricidade! Desliga o disjuntor geral imediatamente antes de mexer em qualquer tomada ou fio.";
      }

      setSosMessages(prev => [...prev, { sender: 'ai', text: aiResponse }]);
      speakText(aiResponse);
    }, 1000);
  };

  const handleDiagnose = async (textToUse?: string) => {
    const query = textToUse !== undefined ? textToUse : description;
    if (!query && !imageFile && !audioBlob) {
      setErrorMsg('Por favor, descreva o problema, envie uma foto ou grave um áudio.');
      return;
    }

    setErrorMsg(null);
    setLoading(true);
    setCurrentResult(null);
    setCompletedSteps([]);

    try {
      const res = await fetch('/api/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: query || (audioBlob ? 'Relato de áudio do problema residencial' : ''),
          image: imageFile,
          audio: audioBlob,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao consultar o especialista.');
      }

      const fullResult: DiagnosisResult = {
        ...data,
        id: Math.random().toString(36).substring(2, 9),
        timestamp: Date.now(),
        userQuery: query || (audioBlob ? 'Análise de áudio gravado' : 'Análise de foto'),
        imageUrl: imageFile || undefined,
      };

      setCurrentResult(fullResult);
      saveToHistory(fullResult);
      setActiveTab('diagnostico');
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro de conexão com o ConsertaAí.');
    } finally {
      setLoading(false);
    }
  };

  const handlePresetSelect = (preset: PresetScenario) => {
    setDescription(preset.description);
    handleDiagnose(preset.description);
  };

  const toggleStep = (index: number) => {
    if (completedSteps.includes(index)) {
      setCompletedSteps(completedSteps.filter(i => i !== index));
    } else {
      setCompletedSteps([...completedSteps, index]);
    }
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('conserta_ai_history');
  };

  const shareOnWhatsApp = () => {
    if (!currentResult) return;
    const text = `🚨 *Perrengue em casa resolvido com o ConsertaAí!* 🏠\n\n` +
      `*Problema:* ${currentResult.problema_identificado}\n` +
      `*Nível de Risco:* ${currentResult.nivel_perigo}\n\n` +
      `O app deu o passo a passo exato! Baixe e teste também.`;
    
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const shareBadgeOnWhatsApp = () => {
    const text = `🏆 *Certificado de Gambiarra Segura - Nível Master!* 🛠️\n\n` +
      `Resolvi o perrengue em casa sozinho com segurança usando o assistente inteligente do *ConsertaAí*! 🇧🇷`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const getDangerBadge = (nivel: string) => {
    const n = (nivel || '').toLowerCase();
    if (n.includes('baixo')) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 border border-emerald-200">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Baixo (Pode mexer sozinho)
        </span>
      );
    } else if (n.includes('médio') || n.includes('medio')) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Médio (Cuidado necessário)
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-rose-100 text-rose-800 border border-rose-200 animate-pulse">
          <ShieldAlert className="w-3.5 h-3.5 text-rose-600" /> Alto (Perigo! Chame profissional)
        </span>
      );
    }
  };

  const isLowRisk = currentResult && (currentResult.nivel_perigo || '').toLowerCase().includes('baixo');

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased pb-16">
      {/* Top Banner / Navbar */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-5xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {/* Novo Ícone Gráfico do App */}
            <div className="w-10 h-10 rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center shadow-inner border border-slate-800 shrink-0">
              <img 
                src="/logo-consertaai.png" 
                alt="ConsertaAí Logo" 
                className="w-full h-full object-cover" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
                ConsertaAí <span className="text-xs px-2 py-0.5 bg-amber-500/20 text-amber-400 rounded-full font-normal">Brasil</span>
              </h1>
              <p className="text-xs text-slate-400">Especialista sénior em manutenção e reparos domésticos</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-xs flex-wrap justify-center">
            <button
              onClick={activateSosMode}
              className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white px-3.5 py-1.5 rounded-lg font-bold transition shadow-sm animate-pulse cursor-pointer"
            >
              <Mic className="w-3.5 h-3.5" /> 🎙️ SOS Mão na Massa
            </button>
            <button
              onClick={() => setActiveTab('clube')}
              className="flex items-center gap-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 px-3 py-1.5 rounded-lg border border-amber-500/30 transition cursor-pointer font-semibold"
            >
              <Crown className="w-3.5 h-3.5" /> Clube VIP
            </button>
            <a 
              href="tel:193" 
              className="flex items-center gap-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 px-3 py-1.5 rounded-lg border border-rose-800/60 transition"
              title="Bombeiros em caso de emergência elétrica ou gás"
            >
              <PhoneCall className="w-3.5 h-3.5" /> 193
            </a>
            <button 
              onClick={() => {
                setDescription('');
                setImageFile(null);
                setAudioBlob(null);
                setCurrentResult(null);
              }}
              className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg transition cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Novo Reparo
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        
        {/* SOS Mão na Massa Overlay Modal (Hands-Free Voice Mode) */}
        {sosActive && (
          <div className="fixed inset-0 bg-slate-950/90 z-50 flex items-center justify-center p-4 backdrop-blur-md animate-fadeIn">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 text-white shadow-2xl flex flex-col h-[500px]">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping"></span>
                  <h3 className="font-extrabold text-base text-amber-400">SOS Mão na Massa (Modo Voz Ativo)</h3>
                </div>
                <button 
                  onClick={() => {
                    stopSpeaking();
                    setSosActive(false);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer"
                >
                  Fechar ✕
                </button>
              </div>

              {/* Chat Voice Visualizer & Transcript */}
              <div className="flex-1 overflow-y-auto py-4 space-y-3 pr-2">
                {sosMessages.map((msg, index) => (
                  <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed ${
                      msg.sender === 'user' 
                        ? 'bg-amber-500 text-slate-950 font-medium rounded-br-none' 
                        : 'bg-slate-800 text-slate-100 rounded-bl-none border border-slate-700'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>

              {/* Speaking Indicator & Quick Action Controls */}
              <div className="pt-4 border-t border-slate-800 flex flex-col gap-3">
                {isSpeaking && (
                  <div className="flex items-center justify-center gap-2 text-xs text-amber-400 bg-amber-500/10 py-1.5 rounded-xl border border-amber-500/20 animate-pulse">
                    <Volume2 className="w-4 h-4" /> A falar com o técnico sênior... (Pode responder em voz alta)
                  </div>
                )}
                
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Digite ou descreva o que está a acontecer agora..."
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleSosReply((e.target as HTMLInputElement).value);
                        (e.target as HTMLInputElement).value = '';
                      }
                    }}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500"
                  />
                  {isSpeaking ? (
                    <button 
                      onClick={stopSpeaking}
                      className="bg-rose-600 hover:bg-rose-700 text-white px-4 rounded-xl flex items-center justify-center transition cursor-pointer"
                      title="Parar áudio"
                    >
                      <VolumeX className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => handleSosReply("Estou com dificuldades aqui, o que faço a seguir?")}
                      className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-4 rounded-xl text-xs transition cursor-pointer"
                    >
                      Enviar
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
            O que quebrou em casa hoje?
          </h2>
          <p className="text-slate-600 text-sm">
            Envie uma foto, grave um áudio ou ative o <span className="font-bold text-amber-600">SOS Mão na Massa</span> para ter um técnico ao seu lado em tempo real.
          </p>
        </div>

        {/* Input Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 sm:p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Description & Presets */}
            <div className="md:col-span-2 flex flex-col gap-4">
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Descreva o problema ou grave um áudio
                  </label>
                  
                  {/* Audio Recording Widget Action */}
                  <div className="flex items-center gap-2">
                    {isRecording ? (
                      <button
                        onClick={stopRecording}
                        className="bg-rose-600 text-white text-xs px-3 py-1 rounded-lg flex items-center gap-1.5 animate-pulse cursor-pointer"
                      >
                        <Square className="w-3 h-3 fill-current" /> Parar Gravação
                      </button>
                    ) : (
                      <button
                        onClick={startRecording}
                        className="bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-900 text-xs px-3 py-1 rounded-lg border border-slate-200 flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Mic className="w-3.5 h-3.5 text-amber-600" /> Gravar Áudio
                      </button>
                    )}
                  </div>
                </div>

                {audioBlob && (
                  <div className="mb-2 p-2 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800">
                    <span>🎙️ Áudio gravado com sucesso pronto para análise!</span>
                    <button onClick={() => setAudioBlob(null)} className="text-rose-600 font-bold hover:underline cursor-pointer">Apagar</button>
                  </div>
                )}

                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Ex: A torneira da pia da cozinha não para de pingar mesmo fechando forte..."
                  rows={4}
                  className="w-full rounded-xl border border-slate-200 p-3 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-slate-50/50 resize-none transition"
                />
              </div>

              {/* Quick Presets */}
              <div>
                <span className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Exemplos comuns (Clique para testar):
                </span>
                <div className="flex flex-wrap gap-2">
                  {PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => handlePresetSelect(preset)}
                      className="text-xs bg-slate-100 hover:bg-amber-50 hover:text-amber-900 hover:border-amber-200 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 transition text-left cursor-pointer"
                    >
                      {preset.title}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Photo Upload Area */}
            <div className="flex flex-col justify-between">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                  Foto do problema (Opcional)
                </label>
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center hover:border-amber-400 transition bg-slate-50/50 relative group">
                  {imageFile ? (
                    <div className="relative">
                      <img 
                        src={imageFile} 
                        alt="Problema" 
                        className="w-full h-32 object-cover rounded-lg mx-auto"
                      />
                      <button 
                        onClick={() => setImageFile(null)}
                        className="absolute top-1 right-1 bg-slate-900/80 text-white rounded-full p-1 text-xs hover:bg-rose-600 transition cursor-pointer"
                        title="Remover foto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <label className="cursor-pointer flex flex-col items-center justify-center py-4">
                      <Camera className="w-8 h-8 text-slate-400 mb-2 group-hover:text-amber-500 transition" />
                      <span className="text-xs font-medium text-slate-600">Clique para enviar foto</span>
                      <span className="text-[10px] text-slate-400 mt-0.5">PNG, JPG até 10MB</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleImageUpload} 
                        className="hidden" 
                      />
                    </label>
                  )}
                </div>
              </div>

              <div className="mt-4">
                {errorMsg && (
                  <div className="mb-3 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                    <span>{errorMsg}</span>
                  </div>
                )}
                <button
                  onClick={() => handleDiagnose()}
                  disabled={loading}
                  className="w-full bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-950 font-bold py-3 px-4 rounded-xl shadow-sm transition flex items-center justify-center gap-2 disabled:opacity-50 text-sm cursor-pointer"
                >
                  {loading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Diagnosticando...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Pedir Diagnóstico ConsertaAí</span>
                    </>
                  )}
                </button>
              </div>

            </div>

          </div>
        </div>

        {/* Results / Navigation Tabs */}
        {(currentResult || history.length > 0) && (
          <div className="flex border-b border-slate-200 mb-6 justify-between items-center flex-wrap gap-4">
            <div className="flex border-b border-transparent -mb-px">
              <button
                onClick={() => setActiveTab('diagnostico')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition flex items-center gap-2 cursor-pointer ${
                  activeTab === 'diagnostico' 
                    ? 'border-amber-500 text-amber-700' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Wrench className="w-4 h-4" /> Diagnóstico Atual
              </button>
              <button
                onClick={() => setActiveTab('json')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition flex items-center gap-2 cursor-pointer ${
                  activeTab === 'json' 
                    ? 'border-amber-500 text-amber-700' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Code className="w-4 h-4" /> JSON Puro (Prompt Mode)
              </button>
              <button
                onClick={() => setActiveTab('historico')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition flex items-center gap-2 cursor-pointer ${
                  activeTab === 'historico' 
                    ? 'border-amber-500 text-amber-700' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Clock className="w-4 h-4" /> Histórico ({history.length})
              </button>
              <button
                onClick={() => setActiveTab('clube')}
                className={`pb-3 px-4 text-sm font-semibold border-b-2 transition flex items-center gap-2 cursor-pointer ${
                  activeTab === 'clube' 
                    ? 'border-amber-500 text-amber-700' 
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Crown className="w-4 h-4 text-amber-500" /> Clube VIP
              </button>
            </div>

            {/* WhatsApp Viral Share Button (Visible when diagnosis is active) */}
            {currentResult && activeTab === 'diagnostico' && (
              <button
                onClick={shareOnWhatsApp}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-2 rounded-lg flex items-center gap-1.5 transition shadow-sm cursor-pointer mb-2"
              >
                <Share2 className="w-3.5 h-3.5" /> Partilhar Perrengue no WhatsApp
              </button>
            )}
          </div>
        )}

        {/* Tab 1: Diagnóstico Atual */}
        {activeTab === 'diagnostico' && currentResult && (
          <div className="space-y-6 animate-fadeIn">
            {/* Main Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="bg-slate-900 text-white p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold">Problema Identificado</span>
                  <h3 className="text-xl sm:text-2xl font-bold mt-1 text-white">
                    {currentResult.problema_identificado}
                  </h3>
                  {currentResult.userQuery && (
                    <p className="text-xs text-slate-400 mt-1 italic">
                      "{currentResult.userQuery}"
                    </p>
                  )}
                </div>
                <div>
                  {getDangerBadge(currentResult.nivel_perigo)}
                </div>
              </div>

              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Ferramentas Necessárias + Vitrine Afiliados + Preço Justo */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-amber-600" /> Ferramentas e Itens Caseiros
                  </h4>
                  <ul className="space-y-2 mb-6">
                    {currentResult.ferramentas_necessarias?.map((tool, idx) => (
                      <li key={idx} className="flex items-center gap-3 bg-slate-50 px-3 py-2.5 rounded-xl border border-slate-100 text-sm font-medium text-slate-800">
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold shrink-0">
                          {idx + 1}
                        </span>
                        <span className="flex-1">{tool}</span>
                        <a 
                          href={`https://www.amazon.com.br/s?k=${encodeURIComponent(tool)}`} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] bg-amber-100 hover:bg-amber-200 text-amber-900 px-2 py-1 rounded font-semibold transition flex items-center gap-1"
                          title="Comprar ferramenta online"
                        >
                          <ShoppingBag className="w-3 h-3" /> Comprar
                        </a>
                      </li>
                    ))}
                  </ul>

                  {/* Preço Justo Mão de Obra Box */}
                  {currentResult.preco_justo_estimado && (
                    <div className="mb-6 bg-emerald-50 border border-emerald-200 rounded-xl p-4">
                      <h5 className="text-xs font-bold uppercase tracking-wider text-emerald-800 mb-1 flex items-center gap-1.5">
                        <DollarSign className="w-4 h-4 text-emerald-600" /> Estimativa de Preço Justo (Mão de Obra)
                      </h5>
                      <p className="text-sm text-emerald-950 font-bold">
                        {currentResult.preco_justo_estimado}
                      </p>
                      <p className="text-[11px] text-emerald-800 mt-0.5">
                        Valor médio sugerido para contratação segura no mercado brasileiro.
                      </p>
                    </div>
                  )}

                  {/* Professional Warning Box */}
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-amber-800 mb-1 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-600" /> Quando Chamar o Profissional
                    </h5>
                    <p className="text-sm text-amber-950 font-medium leading-relaxed">
                      {currentResult.quando_chamar_profissional}
                    </p>
                  </div>
                </div>

                {/* Passo a Passo */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> Passo a Passo para Resolver
                  </h4>
                  <div className="space-y-3">
                    {currentResult.passo_a_passo?.map((step, idx) => {
                      const isDone = completedSteps.includes(idx);
                      return (
                        <div 
                          key={idx}
                          onClick={() => toggleStep(idx)}
                          className={`p-3.5 rounded-xl border transition cursor-pointer flex items-start gap-3 ${
                            isDone 
                              ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900 line-through opacity-75' 
                              : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                          }`}
                        >
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                            isDone ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {isDone ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                          </div>
                          <div className="text-sm leading-snug flex-1">
                            {step}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-4 text-center">
                    <span className="text-xs text-slate-400">
                      Clique em cada passo conforme for concluindo ({completedSteps.length} de {currentResult.passo_a_passo?.length || 0} concluídos)
                    </span>
                  </div>
                </div>

              </div>
            </div>

            {/* GAMIFICATION: Troféu "Gambiarra Master" (Visible if Risk is Low) */}
            {isLowRisk && (
              <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-6 text-slate-950 shadow-md flex flex-col sm:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4 text-center sm:text-left">
                  <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center shrink-0 mx-auto">
                    <Award className="w-8 h-8 text-slate-950" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase tracking-widest font-extrabold bg-slate-950/10 px-2 py-0.5 rounded-full">Gamificação Viral</span>
                    <h4 className="text-lg font-extrabold mt-1">Certificado de Gambiarra Segura - Nível Master</h4>
                    <p className="text-xs text-slate-900 mt-0.5">Parabéns! Diagnosticou um problema de risco baixo e está pronto para resolver por conta própria.</p>
                  </div>
                </div>
                <button
                  onClick={shareBadgeOnWhatsApp}
                  className="bg-slate-950 hover:bg-slate-900 text-amber-400 font-bold px-4 py-2.5 rounded-xl text-xs transition flex items-center gap-2 shrink-0 cursor-pointer shadow"
                >
                  <Share2 className="w-4 h-4" /> Partilhar Insígnia no WhatsApp
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: JSON Puro (Prompt Mode) */}
        {activeTab === 'json' && currentResult && (
          <div className="bg-slate-900 rounded-2xl shadow-md p-6 text-slate-200 font-mono text-xs overflow-hidden">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
              <span className="text-amber-400 font-bold flex items-center gap-2">
                <Code className="w-4 h-4" /> JSON Exato Solicitado no Prompt
              </span>
              <button
                onClick={() => {
                  const cleanObj = {
                    problema_identificado: currentResult.problema_identificado,
                    nivel_perigo: currentResult.nivel_perigo,
                    ferramentas_necessarias: currentResult.ferramentas_necessarias,
                    preco_justo_estimado: currentResult.preco_justo_estimado,
                    passo_a_passo: currentResult.passo_a_passo,
                    quando_chamar_profissional: currentResult.quando_chamar_profissional,
                  };
                  navigator.clipboard.writeText(JSON.stringify(cleanObj, null, 2));
                  alert('JSON copiado para a área de transferência!');
                }}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition font-sans cursor-pointer"
              >
                Copiar JSON
              </button>
            </div>
            <pre className="overflow-x-auto text-emerald-400 p-2 leading-relaxed">
              {JSON.stringify({
                problema_identificado: currentResult.problema_identificado,
                nivel_perigo: currentResult.nivel_perigo,
                ferramentas_necessarias: currentResult.ferramentas_necessarias,
                preco_justo_estimado: currentResult.preco_justo_estimado,
                passo_a_passo: currentResult.passo_a_passo,
                quando_chamar_profissional: currentResult.quando_chamar_profissional,
              }, null, 2)}
            </pre>
          </div>
        )}

        {/* Tab 3: Histórico */}
        {activeTab === 'historico' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500">
                Reparos Anteriores Salvos ({history.length})
              </h3>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="text-xs text-rose-600 hover:text-rose-800 font-medium flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Limpar Histórico
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-slate-200">
                <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-sm text-slate-500">Nenhum diagnóstico no histórico ainda.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {history.map((item) => (
                  <div 
                    key={item.id}
                    onClick={() => {
                      setCurrentResult(item);
                      setActiveTab('diagnostico');
                    }}
                    className="bg-white p-4 rounded-xl border border-slate-200 hover:border-amber-400 transition cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-slate-400">
                          {new Date(item.timestamp || Date.now()).toLocaleDateString('pt-BR')} às {new Date(item.timestamp || Date.now()).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        {getDangerBadge(item.nivel_perigo)}
                      </div>
                      <h4 className="font-bold text-slate-900 text-base mb-1">{item.problema_identificado}</h4>
                      <p className="text-xs text-slate-500 line-clamp-2">{item.userQuery}</p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-amber-700 font-semibold">
                      <span>Ver passo a passo</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Clube VIP (Assinatura Premium via Stripe) */}
        {activeTab === 'clube' && (
          <div className="bg-white rounded-2xl border border-amber-200 p-8 shadow-sm max-w-2xl mx-auto text-center animate-fadeIn">
            <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-inner">
              <Crown className="w-8 h-8" />
            </div>
            <span className="text-xs font-bold uppercase tracking-widest bg-amber-100 text-amber-800 px-3 py-1 rounded-full">Clube ConsertaAí VIP</span>
            <h3 className="text-2xl font-black text-slate-900 mt-2">Gestão Completa + SOS Mão na Massa por Apenas R$ 9,90/mês</h3>
            <p className="text-sm text-slate-600 mt-2 mb-6">
              Tenha acesso ilimitado ao assistente de voz em tempo real, histórico sincronizado na nuvem e suporte prioritário para qualquer emergência doméstica.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left mb-8">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-900 uppercase flex items-center gap-1.5 mb-1">
                  <Check className="w-4 h-4 text-emerald-600" /> SOS Mão na Massa Ilimitado
                </h4>
                <p className="text-xs text-slate-500">Assistente de voz ativo para guiar os seus reparos em tempo real.</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-900 uppercase flex items-center gap-1.5 mb-1">
                  <Check className="w-4 h-4 text-emerald-600" /> Histórico em Nuvem
                </h4>
                <p className="text-xs text-slate-500">Guarde o diário de manutenções de todas as suas habitações.</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-900 uppercase flex items-center gap-1.5 mb-1">
                  <Check className="w-4 h-4 text-emerald-600" /> Alertas Sazonais
                </h4>
                <p className="text-xs text-slate-500">Avisos preventivos automáticos antes das épocas de chuva e calor.</p>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-900 uppercase flex items-center gap-1.5 mb-1">
                  <Check className="w-4 h-4 text-emerald-600" /> Suporte Prioritário
                </h4>
                <p className="text-xs text-slate-500">Atendimento prioritário com IA especialista a qualquer hora.</p>
              </div>
            </div>

            <button
              onClick={() => {
                // Cole aqui o link oficial gerado no painel do Stripe para o ConsertaAí VIP
                const stripeCheckoutUrl = "https://buy.stripe.com/SEU_LINK_REAL_AQUI";
                window.open(stripeCheckoutUrl, "_blank");
              }}
              className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-3.5 px-6 rounded-xl transition shadow text-sm cursor-pointer"
            >
              Tornar-se Membro VIP (R$ 9,90/mês)
            </button>
            <p className="text-[11px] text-slate-400 mt-3">Pagamento processado de forma segura pelo Stripe. Cancele quando quiser.</p>
          </div>
        )}

        {/* Empty State when no result yet */}
        {!currentResult && history.length === 0 && activeTab !== 'clube' && (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center max-w-md mx-auto mt-4">
            <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto mb-3">
              <Wrench className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Pronto para consertar?</h3>
            <p className="text-xs text-slate-500 mb-4">
              Escolha um dos exemplos rápidos acima, digite seu problema ou clique no botão vermelho <span className="font-bold text-rose-600">SOS Mão na Massa</span> para começar.
            </p>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="max-w-5xl mx-auto px-4 mt-16 text-center text-xs text-slate-400 border-t border-slate-200 pt-6">
        <p>ConsertaAí • Inteligência em Manutenção Doméstica para o Brasil 🇧🇷</p>
        <p className="mt-1">Em caso de risco elétrico grave ou vazamento de gás, desligue os registros gerais imediatamente.</p>
      </footer>
    </div>
  );
}
