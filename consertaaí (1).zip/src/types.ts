export interface DiagnosisResult {
  problema_identificado: string;
  nivel_perigo: 'Baixo' | 'Médio' | 'Alto' | string;
  ferramentas_necessarias: string[];
  passo_a_passo: string[];
  quando_chamar_profissional: string;
  preco_justo_estimado?: string;
  timestamp?: number;
  id?: string;
  userQuery?: string;
  imageUrl?: string;
}

export interface PresetScenario {
  id: string;
  title: string;
  category: 'hidraulica' | 'eletrica' | 'infiltracao' | 'eletrodomestico';
  description: string;
  image?: string;
}
